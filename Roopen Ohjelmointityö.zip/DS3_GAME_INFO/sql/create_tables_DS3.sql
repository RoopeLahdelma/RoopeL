CREATE TABLE weapons(
id int auto_increment not null,
types varchar(20) not null,
buildtype varchar(100) not null,
lisat varchar(200) not null,
primary key(id)
)engine=innoDB;