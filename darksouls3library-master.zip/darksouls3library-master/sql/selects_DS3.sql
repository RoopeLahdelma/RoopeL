SELECT id, types, buildtype, lisat
FROM weapons;