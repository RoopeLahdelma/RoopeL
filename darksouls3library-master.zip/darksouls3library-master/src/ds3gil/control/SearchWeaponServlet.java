package ds3gil.control;

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ds3.model.dao.ds3DAO;
import ds3gil.model.WeaponList;

/**
 * Servlet implementation class SearchWeaponServlet
 */
@WebServlet("/search-weapon")
public class SearchWeaponServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = null;
		
		try {
			
			String idStr = request.getParameter("id");
			
			int id = new Integer(idStr);
			ds3DAO ds3dao = new ds3DAO();
			WeaponList weapon = ds3dao.findWeapon(id);
			request.setAttribute("weapon", weapon);
			String type = request.getParameter("types");
			String jsp = "/view/searchweapon.jsp";
			getServletContext().getRequestDispatcher(jsp).forward(request, response);

			
		}
		//Virheen tapahtuessa toimenpiteet:
		catch (Exception e) {
			error = "No weapons found with this id!";
			
			
		}if (error != null) {
			String Message = URLEncoder.encode(error, "UTF-8");
			response.sendRedirect("weapons?viesti="  + Message);
			
		} 
		
		
	}
	
	
	//Virhetilannetta varten tehty rerout.
	protected void doGetGoAgane(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ds3DAO weapondao = new ds3DAO();
		ArrayList<WeaponList> weapons = weapondao.findAll();		
		request.setAttribute("weapons", weapons);
		
		
		String jsp = "/view/listweapons.jsp"; 
		RequestDispatcher dispather = getServletContext().getRequestDispatcher(jsp);
		dispather.forward(request, response);
	}
	
	

	
	
}
